/* =========================================================
   MOTORBASE — logique du site
   Catalogue en dur ci-dessous : à remplacer plus tard par un
   appel à ta propre API / base de données.
   ========================================================= */

const PRODUCTS = [
  { id: "p01", ref: "FR-4410-BX", name: "Disque de frein ventilé avant", cat: "freinage", icon: "🛑", price: 34.90, stock: "in", desc: "Disque de frein avant ventilé, diamètre 280mm. Compatible multi-marques, monté et équilibré en usine." },
  { id: "p02", ref: "FR-2201-PL", name: "Jeu de plaquettes de frein avant", cat: "freinage", icon: "🟫", price: 22.50, stock: "in", desc: "Jeu de 4 plaquettes avant, garniture céramique basse poussière, avec témoin d'usure intégré." },
  { id: "p03", ref: "FR-9012-TB", name: "Tambour de frein arrière", cat: "freinage", icon: "⚫", price: 41.20, stock: "low", desc: "Tambour de frein arrière renforcé, traitement anti-corrosion." },
  { id: "p04", ref: "MT-1187-FL", name: "Filtre à huile moteur", cat: "moteur", icon: "🧰", price: 8.90, stock: "in", desc: "Filtre à huile toutes saisons, joint silicone, compatible essence et diesel." },
  { id: "p05", ref: "MT-3305-CR", name: "Courroie de distribution", cat: "moteur", icon: "🔗", price: 54.00, stock: "in", desc: "Kit courroie de distribution avec galets tendeurs, référence constructeur d'origine." },
  { id: "p06", ref: "MT-7742-BG", name: "Bougie d'allumage (jeu de 4)", cat: "moteur", icon: "⚡", price: 19.90, stock: "in", desc: "Jeu de 4 bougies iridium longue durée, meilleure combustion et démarrage à froid." },
  { id: "p07", ref: "CR-5521-PH", name: "Phare avant gauche LED", cat: "carrosserie", icon: "💡", price: 89.00, stock: "low", desc: "Bloc optique avant gauche à LED, homologué CE, montage direct sans modification." },
  { id: "p08", ref: "CR-1183-RT", name: "Rétroviseur extérieur droit", cat: "carrosserie", icon: "🪞", price: 47.50, stock: "in", desc: "Rétroviseur électrique droit, coque à peindre, dégivrant intégré." },
  { id: "p09", ref: "CR-6640-PC", name: "Pare-chocs avant brut", cat: "carrosserie", icon: "🚗", price: 132.00, stock: "in", desc: "Pare-chocs avant brut à peindre, fixations incluses, qualité équivalente origine." },
  { id: "p10", ref: "EL-2290-BT", name: "Batterie 12V 70Ah", cat: "electricite", icon: "🔋", price: 96.90, stock: "in", desc: "Batterie 12V 70Ah 640A, technologie EFB, garantie 2 ans." },
  { id: "p11", ref: "EL-4471-CP", name: "Capteur ABS avant", cat: "electricite", icon: "📡", price: 27.30, stock: "low", desc: "Capteur de roue ABS avant, connecteur d'origine, testé en sortie d'usine." },
  { id: "p12", ref: "EL-8802-AL", name: "Alternateur 90A reconditionné", cat: "electricite", icon: "🔌", price: 118.00, stock: "in", desc: "Alternateur reconditionné 90A, contrôlé sur banc, échange standard possible." },
];

const CATS = {
  freinage: "Freinage",
  moteur: "Moteur",
  carrosserie: "Carrosserie",
  electricite: "Électricité"
};

let cart = JSON.parse(localStorage.getItem("motorbase_cart") || "[]");
let activeFilters = { cat: new Set(), stock: new Set() };
let searchTerm = "";

/* ---------- rendu catalogue ---------- */
function renderProducts() {
  const grid = document.getElementById("productGrid");
  const term = searchTerm.trim().toLowerCase();

  const filtered = PRODUCTS.filter(p => {
    const matchesTerm = !term || p.name.toLowerCase().includes(term) || p.ref.toLowerCase().includes(term);
    const matchesCat = activeFilters.cat.size === 0 || activeFilters.cat.has(p.cat);
    const matchesStock = activeFilters.stock.size === 0 || activeFilters.stock.has(p.stock);
    return matchesTerm && matchesCat && matchesStock;
  });

  if (filtered.length === 0) {
    grid.innerHTML = `<div class="no-results">Aucune pièce ne correspond à ta recherche. Essaie une autre référence ou catégorie.</div>`;
    return;
  }

  grid.innerHTML = filtered.map(p => `
    <div class="product-card" data-id="${p.id}">
      <div class="product-thumb">
        <span class="stock-badge ${p.stock}">${p.stock === "in" ? "En stock" : "Stock limité"}</span>
        <span>${p.icon}</span>
      </div>
      <div class="product-body">
        <span class="product-cat">${CATS[p.cat]}</span>
        <div class="product-title">${p.name}</div>
        <div class="product-ref mono">Réf. ${p.ref}</div>
        <div class="product-foot">
          <div class="product-price">${p.price.toFixed(2)}€ <small>TTC</small></div>
          <button class="add-btn" data-add="${p.id}" aria-label="Ajouter au panier">+</button>
        </div>
      </div>
    </div>
  `).join("");
}

/* ---------- filtres ---------- */
function bindFilters() {
  document.querySelectorAll("[data-filter-cat]").forEach(el => {
    el.addEventListener("change", () => {
      const val = el.dataset.filterCat;
      el.checked ? activeFilters.cat.add(val) : activeFilters.cat.delete(val);
      renderProducts();
    });
  });
  document.querySelectorAll("[data-filter-stock]").forEach(el => {
    el.addEventListener("change", () => {
      const val = el.dataset.filterStock;
      el.checked ? activeFilters.stock.add(val) : activeFilters.stock.delete(val);
      renderProducts();
    });
  });
}

/* ---------- recherche "scanner" + barre catalogue ---------- */
function bindSearch() {
  const scannerInput = document.getElementById("scannerInput");
  const scannerResult = document.getElementById("scannerResult");
  scannerInput.addEventListener("input", () => {
    const val = scannerInput.value.trim();
    if (!val) { scannerResult.textContent = ""; return; }
    const matches = PRODUCTS.filter(p =>
      p.name.toLowerCase().includes(val.toLowerCase()) || p.ref.toLowerCase().includes(val.toLowerCase())
    );
    scannerResult.textContent = matches.length
      ? `> ${matches.length} référence(s) trouvée(s)`
      : `> aucune correspondance dans le stock`;
  });
  scannerInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      searchTerm = scannerInput.value;
      document.getElementById("catalogSearch").value = scannerInput.value;
      document.getElementById("catalogue").scrollIntoView({ behavior: "smooth" });
      renderProducts();
    }
  });

  document.querySelectorAll("[data-tag]").forEach(btn => {
    btn.addEventListener("click", () => {
      scannerInput.value = btn.dataset.tag;
      scannerInput.dispatchEvent(new Event("input"));
    });
  });

  const catalogSearch = document.getElementById("catalogSearch");
  catalogSearch.addEventListener("input", () => {
    searchTerm = catalogSearch.value;
    renderProducts();
  });
}

/* ---------- panier ---------- */
function saveCart() {
  localStorage.setItem("motorbase_cart", JSON.stringify(cart));
}

function addToCart(id) {
  const product = PRODUCTS.find(p => p.id === id);
  if (!product) return;
  const line = cart.find(l => l.id === id);
  if (line) line.qty += 1;
  else cart.push({ id, qty: 1 });
  saveCart();
  renderCart();
  showToast(`${product.name} ajouté au panier`);
}

function changeQty(id, delta) {
  const line = cart.find(l => l.id === id);
  if (!line) return;
  line.qty += delta;
  if (line.qty <= 0) cart = cart.filter(l => l.id !== id);
  saveCart();
  renderCart();
}

function removeLine(id) {
  cart = cart.filter(l => l.id !== id);
  saveCart();
  renderCart();
}

function renderCart() {
  const itemsEl = document.getElementById("cartItems");
  const countEl = document.getElementById("cartCount");
  const totalEl = document.getElementById("cartTotal");

  const totalQty = cart.reduce((s, l) => s + l.qty, 0);
  countEl.textContent = totalQty;

  if (cart.length === 0) {
    itemsEl.innerHTML = `<div class="cart-empty">Ton panier est vide.<br>Ajoute une pièce depuis le catalogue.</div>`;
    totalEl.textContent = "0.00€";
    return;
  }

  let total = 0;
  itemsEl.innerHTML = cart.map(l => {
    const p = PRODUCTS.find(pr => pr.id === l.id);
    const lineTotal = p.price * l.qty;
    total += lineTotal;
    return `
      <div class="cart-line">
        <div class="thumb">${p.icon}</div>
        <div class="cart-line-body">
          <div class="name">${p.name}</div>
          <div class="ref mono">Réf. ${p.ref}</div>
          <div class="qty-control">
            <button data-qty-minus="${p.id}">−</button>
            <span>${l.qty}</span>
            <button data-qty-plus="${p.id}">+</button>
          </div>
          <button class="remove" data-remove="${p.id}">Retirer</button>
        </div>
        <div class="cart-line-price">${lineTotal.toFixed(2)}€</div>
      </div>
    `;
  }).join("");
  totalEl.textContent = total.toFixed(2) + "€";
}

function bindCartEvents() {
  document.getElementById("productGrid").addEventListener("click", (e) => {
    const addId = e.target.dataset.add;
    if (addId) addToCart(addId);
  });
  document.getElementById("cartItems").addEventListener("click", (e) => {
    if (e.target.dataset.qtyPlus) changeQty(e.target.dataset.qtyPlus, 1);
    if (e.target.dataset.qtyMinus) changeQty(e.target.dataset.qtyMinus, -1);
    if (e.target.dataset.remove) removeLine(e.target.dataset.remove);
  });

  document.getElementById("openCart").addEventListener("click", openCart);
  document.getElementById("closeCart").addEventListener("click", closeCart);
  document.getElementById("cartOverlay").addEventListener("click", closeCart);

  document.getElementById("checkoutBtn").addEventListener("click", () => {
    if (cart.length === 0) return;
    showToast("Commande simulée — branche un vrai module de paiement pour la mise en prod.");
  });
}

function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("cartOverlay").classList.add("open");
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("cartOverlay").classList.remove("open");
}

/* ---------- toast ---------- */
let toastTimer;
function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

/* ---------- catégories cliquables ---------- */
function bindCategoryTiles() {
  document.querySelectorAll("[data-cat-tile]").forEach(tile => {
    tile.addEventListener("click", () => {
      const cat = tile.dataset.catTile;
      document.querySelectorAll("[data-filter-cat]").forEach(cb => {
        cb.checked = cb.dataset.filterCat === cat;
      });
      activeFilters.cat = new Set([cat]);
      renderProducts();
      document.getElementById("catalogue").scrollIntoView({ behavior: "smooth" });
    });
  });
}

/* ---------- formulaire de contact (mock) ---------- */
function bindContactForm() {
  const form = document.getElementById("contactForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Message envoyé — branche ce formulaire à ton e-mail ou ton CRM.");
    form.reset();
  });
}

/* ---------- init ---------- */
document.addEventListener("DOMContentLoaded", () => {
  renderProducts();
  renderCart();
  bindFilters();
  bindSearch();
  bindCartEvents();
  bindCategoryTiles();
  bindContactForm();
});
