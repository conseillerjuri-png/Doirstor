# MOTORBASE — Site e-commerce pièces auto

Site statique (HTML/CSS/JS pur, sans framework) : catalogue filtrable, recherche
par référence, panier avec persistance locale, formulaire de contact.

## 1. Structure des fichiers

```
motorbase/
├── index.html      → toute la structure de la page
├── css/style.css   → styles
├── js/app.js       → catalogue produits + logique (panier, filtres, recherche)
└── README.md
```

## 2. Tester le site en local (le plus simple)

Aucune installation n'est obligatoire : ouvre simplement `index.html`
dans ton navigateur (double-clic, ou clic droit → Ouvrir avec → navigateur).

Pour un rendu plus fiable (certains navigateurs bloquent certains scripts
en `file://`), lance un petit serveur local :

- **Avec Python** (déjà installé sur Mac/Linux) :
  ```
  cd motorbase
  python3 -m http.server 8000
  ```
  puis ouvre `http://localhost:8000`

- **Avec Node.js** :
  ```
  cd motorbase
  npx serve .
  ```

- **Avec VS Code** : installe l'extension "Live Server", puis clic droit
  sur `index.html` → "Open with Live Server".

## 3. Modifier le catalogue

Tous les produits sont dans `js/app.js`, tout en haut, dans le tableau
`PRODUCTS`. Chaque ligne est un produit :

```js
{ id: "p13", ref: "FR-0001-XX", name: "Nom de la pièce", cat: "freinage", icon: "🛑", price: 19.90, stock: "in", desc: "Description." }
```

- `cat` doit être l'une des clés définies dans `CATS` (freinage, moteur,
  carrosserie, electricite) — ou une nouvelle catégorie que tu ajoutes
  aussi dans `CATS` et dans les cases à cocher du HTML.
- `stock` vaut `"in"` (en stock) ou `"low"` (stock limité).

Pour de vraies images produit, remplace `icon` par une balise `<img>`
dans la fonction `renderProducts()` de `app.js`.

## 4. Mettre le site en ligne (hébergement gratuit)

Le plus simple pour un site statique comme celui-ci :

### Option A — Netlify (glisser-déposer, aucune commande)
1. Va sur https://app.netlify.com/drop
2. Glisse le dossier `motorbase` entier dans la fenêtre
3. Le site est en ligne en quelques secondes, avec une URL fournie

### Option B — GitHub Pages
1. Crée un dépôt GitHub et mets-y le contenu du dossier `motorbase`
2. Dans les paramètres du dépôt → Pages → choisis la branche `main`
3. Le site est publié à `https://ton-compte.github.io/nom-du-depot`

### Option C — Vercel
1. Crée un compte sur https://vercel.com
2. "Add New Project" → importe le dossier ou le dépôt Git
3. Déploiement automatique, URL fournie

Dans les trois cas, ton propre nom de domaine (ex. `motorbase.fr`) peut
être branché ensuite dans les réglages "Domain" de l'hébergeur.

## 5. Limites actuelles à connaître

Ce site est une base fonctionnelle mais reste **côté client uniquement** :

- **Panier** : stocké dans le navigateur (`localStorage`), pas de base de
  données. Chaque visiteur a son propre panier, qui disparaît s'il vide
  son navigateur.
- **Paiement** : le bouton "Passer commande" simule l'action. Pour
  encaisser réellement, il faut brancher un prestataire comme Stripe,
  PayPal ou Mollie (ils fournissent des boutons ou un checkout à
  intégrer, souvent avec un petit backend).
- **Formulaire de contact** : simule l'envoi. Pour qu'il t'envoie
  vraiment un e-mail, connecte-le à un service comme Formspree,
  EmailJS ou Netlify Forms (souvent gratuit, sans backend à héberger).
- **Stock produits** : géré en dur dans `app.js`. Pour un vrai
  catalogue évolutif, il faudra une base de données (ex. Airtable,
  Supabase, ou un back-office e-commerce comme Shopify/PrestaShop) que
  ce front-end pourrait interroger.

## 6. Prochaines étapes possibles

- Ajouter de vraies photos produits
- Brancher un moteur de paiement (Stripe Checkout est le plus rapide)
- Ajouter une vraie base de données produits
- Ajouter un compte client / historique de commandes
